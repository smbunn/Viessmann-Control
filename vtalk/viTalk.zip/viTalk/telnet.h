
#define PORT 83
#define MAX_DESCRIPTOR 20
#define TELNET_BUFFER_SIZE 80

// Prototypes:
void telnet_init( void );
void telnet_task( void );

